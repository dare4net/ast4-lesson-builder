# Lesson 1 Plan — The Biscuit Tin Dilemma

**Series:** KS3 English — Persuasive & Argumentative Writing  
**Topic Slug:** `ks3-disaster-committee`  
**Chapter Title:** Chapter 1: The Biscuit Tin Dilemma  

**Curriculum Skills Taught:**
- Identifying and applying Aristotle's Triad of Persuasion (**Ethos, Pathos, Logos**) in written arguments.
- Distinguishing between authoritative appeal (ethos), emotional appeal (pathos), and logical evidence (logos).
- Constructing balanced 3-part persuasive appeals targeting specific audiences.

**Narrative Beat:** The Emergency Committee is stuck in an endless tea break while a Category 3 storm hits. You step forward as Junior Persuasion Officer to persuade Captain Bluster to declare a Yellow Alert using persuasive triad techniques.

**Handoff Type:** Planted Suspicion  
**Handoff Text:** *"As Captain Bluster agrees to put the committee on yellow alert, a sudden shudder rattles the windowpanes. But the sound didn't come from the ocean outside. It came from deep underground, right beneath the town hall... and it smelled faintly of warm yeast and butter."*

**Design Principle:** **Purpose-Driven Composition.** Every component on every slide is placed with a specific, non-negotiable pedagogical purpose, narrative function, and placement rationale. No filler or arbitrary quotas.

---

## Slide-by-Slide Purpose Breakdown

### Slide 1: 🌧️ Scene 1: Emergency Committee Assembly

**Slide Purpose & Goal:** Establish the disaster setting, introduce committee member conflict, and prompt the learner's first official officer diagnostic decision.

**Components (in order of presentation):**

1. **`heading`**
   - **Props/Content outline:** `content: "🌧️ Scene 1: Emergency Committee Assembly"`, `level: 1`
   - **Pedagogical purpose:** Clear topic/scene anchor.
   - **Narrative function:** Establishes location and time (Wittling Town Hall, 08:30 AM).
   - **Placement rationale:** Top anchor of the slide viewer.

2. **`paragraph`**
   - **Props/Content outline:** Story narrative introducing wind, shortbread tin gavel, and 3-hour tea delay.
   - **Pedagogical purpose:** Contextualize the problem requiring persuasion.
   - **Narrative function:** Establishes high stakes and student role.
   - **Placement rationale:** Immediately follows heading to ground the learner in the scene before visual or interactive assets.

3. **`image`**
   - **Props/Content outline:** Comic-style town hall committee room during storm.
   - **Pedagogical purpose:** Visual anchor to ground non-readers and build comedic disaster atmosphere.
   - **Narrative function:** Visualizes Captain Bluster's chaotic committee.
   - **Placement rationale:** Positioned centrally to give visual context before detailed text inspection.

4. **`accordion`**
   - **Props/Content outline:** 3 expandable panels detailing Captain Bluster, Gerald Nibbs, and Professor Spindle's exact stances.
   - **Pedagogical purpose:** Read & analyze character arguments to identify rhetorical obstacles.
   - **Narrative function:** Meet the committee members you must persuade.
   - **Placement rationale:** Placed after intro text and image so learner inspects detailed positions with scene context established.

5. **`poll`**
   - **Props/Content outline:** `"Who is currently causing the biggest delay in declaring an emergency?"`
   - **Pedagogical purpose:** Immediate active diagnostic check on audience awareness.
   - **Narrative function:** Learner makes their first official officer decision.
   - **Placement rationale:** Concludes the slide, turning inspection into an active opinion decision before proceeding.

---

### Slide 2: ⚖️ Scene 2: The Persuasive Triad (Ethos, Pathos, Logos)

**Slide Purpose & Goal:** Define Aristotle's 3 pillars of persuasion, link each pillar to audience vulnerabilities, and verify term-to-quote acquisition.

**Components (in order of presentation):**

1. **`heading`**
   - **Props/Content outline:** `content: "⚖️ Scene 2: The Persuasive Triad (Ethos, Pathos, Logos)"`
   - **Pedagogical purpose:** Concept title frame.
   - **Narrative function:** Unlocking the Junior Officer's secret persuasive weapon.
   - **Placement rationale:** Top anchor.

2. **`callout`** (`variant: "important"`)
   - **Props/Content outline:** `"Officer's Field Handbook: Aristotle's 3 Pillars"` defining Ethos, Pathos, and Logos.
   - **Pedagogical purpose:** Highlighting rule definitions prominently.
   - **Narrative function:** Reference manual entry.
   - **Placement rationale:** Placed near top so core definitions are learned before practice.

3. **`paragraph`**
   - **Props/Content outline:** Linking Ethos to Bluster (authority), Pathos to Gerald (emotion), and Logos to Agatha (data).
   - **Pedagogical purpose:** Translates abstract theory directly to character application.
   - **Narrative function:** Explaining character vulnerabilities to persuade them.
   - **Placement rationale:** Bridges general definition to specific story application.

4. **`matchingPairs`**
   - **Props/Content outline:** Match `ETHOS`, `PATHOS`, `LOGOS` to exact committee quotes.
   - **Pedagogical purpose:** Practice matching rhetoric pillars to real sentences.
   - **Narrative function:** Decoding committee dialogue.
   - **Placement rationale:** Core concept check following the callout and paragraph explanation.
   - **`markingMode` & rationale:** `auto-mark` (exact quote-to-pillar matches).

5. **`trueFalse`**
   - **Props/Content outline:** Statement testing if Logos relies on emotional stories.
   - **Pedagogical purpose:** Misconception check immediately after matching.
   - **Narrative function:** Quick officer knowledge test.
   - **Placement rationale:** Slide wrap-up verification.
   - **`markingMode` & rationale:** `auto-mark`.

---

### Slide 3: 🔍 Scene 3: Analyzing Committee Arguments

**Slide Purpose & Goal:** Audit real committee statements by sorting them into rhetorical categories, then diagnose why a flawed argument failed.

**Components (in order of presentation):**

1. **`heading`**
   - **Props/Content outline:** `content: "🔍 Scene 3: Analyzing Committee Arguments"`
   - **Pedagogical purpose:** Task anchor.
   - **Narrative function:** Auditing committee transcript with Agatha.
   - **Placement rationale:** Top anchor.

2. **`paragraph`**
   - **Props/Content outline:** Instruction to categorize committee transcript statements.
   - **Pedagogical purpose:** Framed task instruction.
   - **Narrative function:** Audit setup.
   - **Placement rationale:** Task setup before interactive tool.

3. **`categorise`**
   - **Props/Content outline:** 6 statement cards sorted into Ethos, Pathos, or Logos buckets.
   - **Pedagogical purpose:** Deep categorisation practice across multiple examples.
   - **Narrative function:** Sorting transcript evidence into official files.
   - **Placement rationale:** Main interactive activity of the slide.
   - **`markingMode` & rationale:** `auto-mark`.

4. **`callout`** (`variant: "tip"`)
   - **Props/Content outline:** `"Audit Finding: Gerald Nibbs had zero Logos and zero Ethos."`
   - **Pedagogical purpose:** Key analytical takeaway highlighting why arguments fail without balance.
   - **Narrative function:** Officer's debrief finding.
   - **Placement rationale:** Placed after sorting so learner sees the pattern they just uncovered.

5. **`quiz`**
   - **Props/Content outline:** Question analyzing Captain Bluster's authority trap.
   - **Pedagogical purpose:** High-level analysis evaluating argument flaws.
   - **Narrative function:** Spotting Bluster's rhetoric trap.
   - **Placement rationale:** Final concept check of the audit scene.
   - **`markingMode` & rationale:** `auto-mark`.

---

### Slide 4: 🗣️ Scene 4: Crafting the Appeals

**Slide Purpose & Goal:** Scaffold sentence construction by weaving Ethos, Pathos, and Logos into an official Yellow Alert memo draft.

**Components (in order of presentation):**

1. **`heading`**
   - **Props/Content outline:** `content: "🗣️ Scene 4: Crafting the Yellow Alert Memo"`
   - **Pedagogical purpose:** Header anchor.
   - **Narrative function:** Drafting memo for Captain Bluster.
   - **Placement rationale:** Top anchor.

2. **`paragraph`**
   - **Props/Content outline:** Task brief explaining that Bluster will sign only if all 3 pillars are woven into the draft.
   - **Pedagogical purpose:** Set success criteria for writing task.
   - **Narrative function:** Mission brief.
   - **Placement rationale:** Briefing before drafting.

3. **`fillInTheBlank`**
   - **Props/Content outline:** Multi-blank memo draft selecting title (Ethos), statistic (Logos), emotion (Pathos), and modal verb (urgency).
   - **Pedagogical purpose:** Scaffolded sentence assembly balancing all 3 pillars.
   - **Narrative function:** Assembling the legal notice.
   - **Placement rationale:** Central hands-on sentence construction activity.
   - **`markingMode` & rationale:** `self-mark` (selecting correct choices).

4. **`bulletList`**
   - **Props/Content outline:** Breakdown explaining why each selected phrase works (Ethos title, Logos stat, Pathos emotion, Modal verb).
   - **Pedagogical purpose:** Structural deconstruction reinforcing why the completed text succeeds.
   - **Narrative function:** Officer's post-draft review.
   - **Placement rationale:** Placed immediately after `fillInTheBlank` to reflect on completed sentence structure.

---

### Slide 5: 📜 Scene 5: The Junior Officer's First Address

**Slide Purpose & Goal:** Open-ended persuasive synthesis — draft and deliver a 3-sentence formal address combining Ethos, Pathos, and Logos.

**Components (in order of presentation):**

1. **`heading`**
   - **Props/Content outline:** `content: "📜 Scene 5: Deliver Your Address to Captain Bluster"`
   - **Pedagogical purpose:** Header anchor.
   - **Narrative function:** Standing up to address the room.
   - **Placement rationale:** Top anchor.

2. **`paragraph`**
   - **Props/Content outline:** Bluster challenges you: "Give me 3 solid reasons why I should sign right now."
   - **Pedagogical purpose:** Story challenge prompt.
   - **Narrative function:** Character confrontation.
   - **Placement rationale:** Dramatic setup.

3. **`callout`** (`variant: "tip"`)
   - **Props/Content outline:** `"Writing Checklist: Sentence 1 (Ethos), Sentence 2 (Logos), Sentence 3 (Pathos)."`
   - **Pedagogical purpose:** Explicit rubric for synthesis writing.
   - **Narrative function:** Officer speech guide.
   - **Placement rationale:** Placed immediately above input area so criteria are visible during writing.

4. **`shortAnswer`**
   - **Props/Content outline:** Open text input for a 3-sentence persuasive speech.
   - **Pedagogical purpose:** Full open synthesis writing application.
   - **Narrative function:** Delivering your speech aloud.
   - **Placement rationale:** Capstone writing task of the lesson.
   - **`markingMode` & rationale:** `tutor-mark` (requires human review of argument quality and tone).

---

### Slide 6: 🚨 Scene 6: Chapter 1 Resolution & Handoff

**Slide Purpose & Goal:** Celebrate lesson completion, provide success feedback, and transition into Chapter 2 via a narrative cliffhanger.

**Components (in order of presentation):**

1. **`heading`**
   - **Props/Content outline:** `content: "🚨 Scene 6: Yellow Alert Activated!"`
   - **Pedagogical purpose:** Resolution header.
   - **Narrative function:** Committee room victory.
   - **Placement rationale:** Top anchor.

2. **`paragraph`**
   - **Props/Content outline:** Bluster is impressed and signs the Yellow Alert order.
   - **Pedagogical purpose:** Narrative feedback and reward.
   - **Narrative function:** Victory beat.
   - **Placement rationale:** Narrative resolution after synthesis writing.

3. **`callout`** (`variant: "warning"`)
   - **Props/Content outline:** Planted suspicion handoff text (ground shudder & yeast smell).
   - **Pedagogical purpose:** Chapter cliffhanger.
   - **Narrative function:** Transition to Chapter 2.
   - **Placement rationale:** High-impact callout ending the main scene narrative.

4. **`poll`**
   - **Props/Content outline:** Prediction question: "What do you suspect is beneath the town hall floor?"
   - **Pedagogical purpose:** Curiosity driver and predictive engagement for Lesson 2.
   - **Narrative function:** Exit prediction poll.
   - **Placement rationale:** Concluding interactive element of the lesson.

---

## 🖼️ Visual Asset Prompts — Lesson 1

**Slide 1 → `image`**
- *Purpose:* Establish chaotic town hall committee meeting during the storm.
- *Prompt:*
  > "A vibrant comic-adventure style illustration of a Victorian-era town hall committee room during a storm. Rain and wind rattle large arched stained-glass windows in the background. In the foreground, a loud female committee captain in a navy coat bangs a wooden mallet onto a decorative tin of shortbread biscuits. Around a cluttered mahogany table, a puffed-up man holds up a piece of seaweed on a string, and a female professor with round spectacles unrolls an enormous complex weather graph. Saturated teal and gold lighting, lively detailed cartoon aesthetic."

---

## Purpose-Driven Audit Summary

- **Total Components Placed:** 27 across 6 slides.
- **Filler Audit:** **0 filler components.** Every single component has a distinct pedagogical role (definition, practice, analysis, scaffolded writing, synthesis) and narrative function (scene setup, character dialogue, speech delivery, cliffhanger).
- **Placement Rationale Verified:** Every component logically builds upon the component preceding it.
