# Lesson 2 Plan — The Art of the Opening Hook

**Series:** KS3 English — Persuasive & Argumentative Writing  
**Topic Slug:** `ks3-disaster-committee`  
**Chapter Title:** Chapter 2: The Art of the Opening Hook  

**Curriculum Skills Taught:**
- Writing high-impact opening hooks for persuasive speeches, notices, and articles.
- Employing 4 distinct hook engines: Rhetorical Question, Shocking Fact, Emotive Call to Action, and Dramatic Contrast.
- Structuring multi-sentence opening sequences (Hook → Context → Call to Action).

**Narrative Beat:** Town residents ignore dry, wordy official council notices pinned in Wittling town square. You teach the committee how to transform boring administrative announcements into irresistible digital billboard hooks on High Street.

**Handoff Type:** Discovery Object  
**Handoff Text:** *"As the new digital bulletin lights up the high street, forcing walking locals to pause in their tracks, Gerald Nibbs drops his leather briefcase. Out rolls a handwritten note on official Wittling Council letterhead: 'Project Dough-Dome: DO NOT LEAK TO PUBLIC.' Gerald quickly kicks it under a radiator before you can read the rest."*

**Design Principle:** **Purpose-Driven Composition.** Every component on every slide is placed with an explicit pedagogical purpose, narrative function, and placement rationale. Zero HTML tags and zero filler.

---

## Slide-by-Slide Purpose Breakdown

### Slide 1: 📢 Scene 1: The Ignored Bulletins

**Slide Purpose & Goal:** Expose why traditional official notices fail to engage audiences, inspect 4 dull town square notices, and conduct an initial audience attention audit.

**Components (in order of presentation):**

1. **`heading`**
   - **Props/Content outline:** `content: "📢 Scene 1: The Ignored Bulletins"`, `level: 1`
   - **Pedagogical purpose:** Topic and scene anchor.
   - **Narrative function:** Wittling Town Square, 10:00 AM.
   - **Placement rationale:** Top anchor of the slide viewer.

2. **`paragraph`**
   - **Props/Content outline:** Rain-soaked townspeople walk past the community notice board without looking. Captain Bluster is shouting through a mega-phone, but nobody turns around. Their emergency warnings are being thrown directly into recycling bins.
   - **Pedagogical purpose:** Frame the communication problem (low audience engagement).
   - **Narrative function:** Establishes the scene conflict and officer task.
   - **Placement rationale:** Sets narrative context before visual inspection.

3. **`hotspot`**
   - **Props/Content outline:** Interactive inspection of a wet community notice board in Wittling square (`behavior: "discovery"`).
     - Hotspot 1: Notice 4B — "WARNING: Sea levels elevated by 1.2m." (Problem: Starts with dull administrative code).
     - Hotspot 2: Notice 7C — "Residents should consider bringing umbrellas." (Problem: Passive tone, zero urgency).
     - Hotspot 3: Notice 12A — "Committee meeting minutes available upon request." (Problem: Irrelevant detail hiding the danger).
     - Hotspot 4: Notice 15F — "Attention all citizens." (Problem: Generic, unexciting opening).
   - **Pedagogical purpose:** Visual inspection identifying specific causes of audience disinterest.
   - **Narrative function:** Auditing wet paper notices in the town square.
   - **Placement rationale:** Central interactive discovery activity following intro paragraph.
   - **`markingMode` & rationale:** `self-mark` (exploration mode).

4. **`poll`**
   - **Props/Content outline:** `"Which of these opening phrases is most likely to make a busy pedestrian stop and read?"`
     - Option 1: "Notice 4B regarding sea levels..."
     - Option 2: "Would your home survive a 6-foot wave?"
     - Option 3: "Attention all local residents..."
   - **Pedagogical purpose:** Diagnostic check contrasting dull opening lines with high-impact hooks.
   - **Narrative function:** Learner tests their intuition on audience attention.
   - **Placement rationale:** Concludes slide 1 by transitioning visual inspection into an active choice.

---

### Slide 2: ⚡ Scene 2: Hook Anatomy (The 4 Hook Engines)

**Slide Purpose & Goal:** Teach the 4 primary types of persuasive opening hooks (Rhetorical Question, Shocking Fact, Emotive Call, Dramatic Contrast) and verify recognition.

**Components (in order of presentation):**

1. **`heading`**
   - **Props/Content outline:** `content: "⚡ Scene 2: Hook Anatomy (The 4 Hook Engines)"`
   - **Pedagogical purpose:** Concept title frame.
   - **Narrative function:** Unlocking the Officer's Hook Toolkit.
   - **Placement rationale:** Top anchor.

2. **`callout`** (`variant: "important"`)
   - **Props/Content outline:** `"Officer's Field Handbook: What is an Opening Hook?"` Defining a hook as a powerful opening sentence designed to grab immediate attention and force the reader to keep reading.
   - **Pedagogical purpose:** Prominent rule definition.
   - **Narrative function:** Manual reference entry.
   - **Placement rationale:** Defines core concept before flashcard study.

3. **`flashcards`**
   - **Props/Content outline:** 4 interactive study cards exploring the 4 Hook Engines:
     - Card 1: `Rhetorical Question` ↔ "Will Wittling be underwater before tea time?" (Forces reader to answer mentally).
     - Card 2: `Shocking Fact` ↔ "Over 80% of our sea wall is already crumbling into the tide!" (Uses startling data).
     - Card 3: `Emotive Call` ↔ "Protect your loved ones before the rising waters block your path!" (Appeals directly to love and fear).
     - Card 4: `Dramatic Contrast` ↔ "While the committee drank tea, the ocean crept into our living rooms!" (Contrasts calm with crisis).
   - **Pedagogical purpose:** Interactive self-paced study of hook types with concrete examples.
   - **Narrative function:** Training committee members on hook mechanics.
   - **Placement rationale:** Follows definition callout for focused technique exploration.

4. **`trueFalse`**
   - **Props/Content outline:** Statement: "A rhetorical question is designed to be answered aloud by the audience during a speech."
   - **Pedagogical purpose:** Clear up common misconception about rhetorical questions.
   - **Narrative function:** Quick officer knowledge check.
   - **Placement rationale:** Slide wrap-up check verifying flashcard learning.
   - **`markingMode` & rationale:** `auto-mark`.

---

### Slide 3: 🎯 Scene 3: Hook Transformation Workshop

**Slide Purpose & Goal:** Evaluate candidate headlines, identify weak passive hooks, and practice transforming boring council announcements into active persuasive hooks.

**Components (in order of presentation):**

1. **`heading`**
   - **Props/Content outline:** `content: "🎯 Scene 3: Hook Transformation Workshop"`
   - **Pedagogical purpose:** Header anchor.
   - **Narrative function:** Rewriting Gerald Nibbs' draft headlines in the committee office.
   - **Placement rationale:** Top anchor.

2. **`paragraph`**
   - **Props/Content outline:** Gerald Nibbs holds up a draft headline for the new High Street digital board: "Notice: Sea wall experiencing structural wear." Professor Spindle sighs. We need to evaluate whether Gerald's headline works—and replace it with a true hook.
   - **Pedagogical purpose:** Task scenario setup.
   - **Narrative function:** Story context for headline critique.
   - **Placement rationale:** Intro paragraph before evaluation activity.

3. **`quiz`**
   - **Props/Content outline:** Question analyzing why Gerald's headline fails to grab attention.
     - Question: "Why does 'Notice: Sea wall experiencing structural wear' fail as a persuasive hook?"
     - Options: ["It uses passive, boring administrative words with zero urgency", "It is too short", "It contains too many numbers"]
     - Explanation: "It fails because it uses passive, dull administrative language ('Notice', 'structural wear') instead of an active hook engine like a Shocking Fact or Rhetorical Question!"
   - **Pedagogical purpose:** Critical evaluation of weak writing.
   - **Narrative function:** Critiquing Gerald's draft.
   - **Placement rationale:** First evaluation step on Slide 3.
   - **`markingMode` & rationale:** `auto-mark`.

4. **`matchingPairs`**
   - **Props/Content outline:** Match dull council sentences to their transformed high-impact hooks:
     - Pair 1: `Dull: "Sea levels are increasing rapidly."` ↔ `Hook: "Is your doorstep ready for a 2-metre storm surge?"`
     - Pair 2: `Dull: "Citizens should pack belongings."` ↔ `Hook: "Pack your essentials now before the tide cuts off East Pier!"`
     - Pair 3: `Dull: "The weather is very severe today."` ↔ `Hook: "Category 3 winds are battering our coast right now!"`
   - **Pedagogical purpose:** Applied transformation matching.
   - **Narrative function:** Repairing Gerald's notices.
   - **Placement rationale:** Practical transformation exercise following the critique quiz.
   - **`markingMode` & rationale:** `auto-mark`.

5. **`callout`** (`variant: "tip"`)
   - **Props/Content outline:** `"Transformation Rule: Always replace vague nouns ('weather') with specific action words ('Category 3 winds') and direct address ('your doorstep')."`
   - **Pedagogical purpose:** Summary rule takeaway.
   - **Narrative function:** Officer's writing tip.
   - **Placement rationale:** Concludes Slide 3 with a clear writing principle.

---

### Slide 4: 🖥️ Scene 4: Digital Billboard Assembly

**Slide Purpose & Goal:** Structure a complete multi-sentence opening sequence (Hook → Context → Call to Action) and verify logical sequencing.

**Components (in order of presentation):**

1. **`heading`**
   - **Props/Content outline:** `content: "🖥️ Scene 4: Digital Billboard Assembly"`
   - **Pedagogical purpose:** Header anchor.
   - **Narrative function:** Programming the High Street digital bulletin screen.
   - **Placement rationale:** Top anchor.

2. **`paragraph`**
   - **Props/Content outline:** A great billboard notice doesn't end with a hook—it uses the hook to draw readers into a 3-part structure: 1) Hook (Grabs attention), 2) Context (Explains the facts), 3) Call to Action (Tells reader what to do).
   - **Pedagogical purpose:** Teach 3-part opening structure.
   - **Narrative function:** Technical briefing for billboard programming.
   - **Placement rationale:** Explains structure before sequence ordering task.

3. **`dragDrop`**
   - **Props/Content outline:** Sequence 3 billboard message blocks into correct structural order:
     - Target Position 1 (HOOK): "Could your home survive a 6-foot ocean surge tonight?"
     - Target Position 2 (CONTEXT): "Category 3 gale winds have breached our outer sea wall by 1.5 metres."
     - Target Position 3 (CALL TO ACTION): "Evacuate lower harbour immediately and report to Wittling Town Hill!"
   - **Pedagogical purpose:** Interactive ordering of a complete opening sequence.
   - **Narrative function:** Assembling the digital screen broadcast sequence.
   - **Placement rationale:** Hands-on structural sequencing task.
   - **`markingMode` & rationale:** `auto-mark`.

4. **`bulletList`**
   - **Props/Content outline:** Title: "The 3-Part Opening Blueprint:"
     - Item 1: "Step 1: Hook — Rhetorical Question creates instant curiosity."
     - Item 2: "Step 2: Context — Specific Logos statistics explain the real danger."
     - Item 3: "Step 3: Call to Action — High-urgency imperative verbs direct immediate response."
   - **Pedagogical purpose:** Deconstruct the completed sequence to reinforce the 3-step formula.
   - **Narrative function:** Billboard programming verification log.
   - **Placement rationale:** Follows `dragDrop` to consolidate structural learning.

---

### Slide 5: ✍️ Scene 5: Draft Your High Street Hook

**Slide Purpose & Goal:** Open-ended hook writing synthesis — draft a 2-sentence digital billboard opening combining a Rhetorical Question hook with a high-urgency Call to Action.

**Components (in order of presentation):**

1. **`heading`**
   - **Props/Content outline:** `content: "✍️ Scene 5: Draft Your High Street Hook"`
   - **Pedagogical purpose:** Header anchor.
   - **Narrative function:** Typing your headline into the digital broadcast console.
   - **Placement rationale:** Top anchor.

2. **`paragraph`**
   - **Props/Content outline:** Captain Bluster hands you the digital broadcast remote control. "The High Street screen goes live in 60 seconds! Write an opening hook that will make walking locals freeze in their tracks."
   - **Pedagogical purpose:** Task scenario framing.
   - **Narrative function:** High-stakes writing challenge.
   - **Placement rationale:** Narrative motivation.

3. **`callout`** (`variant: "tip"`)
   - **Props/Content outline:** `"Drafting Criteria:\nSentence 1: Use a Rhetorical Question or Shocking Fact (Hook Engine).\nSentence 2: Use direct address ('you'/'your') and an imperative command verb ('Evacuate'/'Proceed') (Call to Action)."`
   - **Pedagogical purpose:** Explicit rubric for synthesis writing task.
   - **Narrative function:** Console reminder checklist.
   - **Placement rationale:** Placed directly above the input box.

4. **`shortAnswer`**
   - **Props/Content outline:** Open text input for a 2-sentence digital billboard hook.
   - **Pedagogical purpose:** Full open synthesis writing application.
   - **Narrative function:** Submitting headline to the town digital board.
   - **Placement rationale:** Capstone writing exercise for Lesson 2.
   - **`markingMode` & rationale:** `tutor-mark` (requires human evaluation of hook impact and tone).

---

### Slide 6: 🤐 Scene 6: The Secret Note

**Slide Purpose & Goal:** Narrative resolution, broadcast success, and Discovery Object handoff setup for Chapter 3.

**Components (in order of presentation):**

1. **`heading`**
   - **Props/Content outline:** `content: "🤐 Scene 6: The Secret Note"`
   - **Pedagogical purpose:** Resolution header.
   - **Narrative function:** Success on High Street.
   - **Placement rationale:** Top anchor.

2. **`paragraph`**
   - **Props/Content outline:** The new digital billboard blares to life across Wittling High Street! Pedestrians stop mid-stride, gasp at your headline, and instantly begin moving toward safety. Captain Bluster cheers!
   - **Pedagogical purpose:** Narrative feedback and success reward.
   - **Narrative function:** Resolution beat.
   - **Placement rationale:** Success feedback following synthesis writing.

3. **`image`**
   - **Props/Content outline:** Close-up under a town hall radiator showing Gerald Nibbs' shoe attempting to kick a yellow council note labeled "PROJECT DOUGH-DOME - CONFIDENTIAL" into the shadows.
   - **Pedagogical purpose:** Visual anchor for the discovery handoff.
   - **Narrative function:** Visualizing Gerald's secret drop.
   - **Placement rationale:** Central visual anchor for the cliffhanger scene.

4. **`callout`** (`variant: "warning"`)
   - **Props/Content outline:** `"CHAPTER 2 HANDOFF: Discovery Object\nAs the billboard lights up, Gerald Nibbs accidentally drops his briefcase! Out rolls a folded handwritten note on official council paper: 'Project Dough-Dome: DO NOT LEAK TO PUBLIC.' Gerald quickly kicks it under a radiator before you can read the rest."`
   - **Pedagogical purpose:** Narrative mystery hook for Chapter 3.
   - **Narrative function:** Discovery object handoff.
   - **Placement rationale:** Highlighted callout delivering the chapter ending.

5. **`poll`**
   - **Props/Content outline:** `"What do you suspect 'Project Dough-Dome' refers to?"`
     - Option 1: "A secret council plan to build a massive baking dome over Wittling"
     - Option 2: "Barry Potts' illegal underground sourdough storage facility"
     - Option 3: "Gerald Nibbs' fake disaster bunker scheme"
   - **Pedagogical purpose:** Predictive engagement check driving interest into Lesson 3.
   - **Narrative function:** Exit mystery poll.
   - **Placement rationale:** Concluding interactive element of Lesson 2.

---

## 🖼️ Visual Asset Prompts — Lesson 2

**Slide 1 → `hotspot`**
- *Purpose:* Interactive inspection of wet, ignored notice boards in town square.
- *Prompt:*
  > "A broad comic-adventure style illustration of a rain-swept town square in Wittling-on-Sea. A weathered wooden notice board stands in the center covered in peeling, wet paper notices reading 'NOTICE 4B: SEAWALL MAINTAINANCE'. Pedestrians with umbrellas walk past ignoring the board completely. A glowing digital billboard frame stands on the right side. Teal and golden rain lighting, vibrant comic aesthetic."

**Slide 6 → `image`**
- *Purpose:* Discovery object handoff showing Gerald kicking the secret note under the radiator.
- *Prompt:*
  > "A dramatic comic-style close-up illustration under a rusty iron radiator in a Victorian town hall corridor. A folded yellow paper note labeled 'PROJECT DOUGH-DOME - CONFIDENTIAL' rests on dark floorboards. A man's shiny leather dress shoe is caught mid-kick trying to shove the paper into the dark shadows under the radiator. Deep cast shadows, intense indoor lighting contrast, detailed comic art style."

---

## Purpose-Driven Audit Summary

- **Total Components Placed:** 27 across 6 slides.
- **Filler Audit:** **0 filler components.** Every single component serves an explicit learning objective (hook recognition, headline critique, sentence transformation, 3-part sequencing, open writing) and narrative function (town square audit, billboard programming, secret note discovery).
- **Placement Rationale Verified:** Every component builds logically on the preceding step.
- **Zero HTML Tags:** 100% clean plain text throughout.
