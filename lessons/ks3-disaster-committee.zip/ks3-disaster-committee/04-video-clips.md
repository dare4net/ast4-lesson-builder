# The Disaster Committee: Short Video Clips Document
### Visual Cue Prompts, Continuity Placement & AI Video Generation Scripts
**Series:** KS3 English — Persuasive & Argumentative Writing
**Topic Slug:** `ks3-disaster-committee`

---

## Overview

These short video clips (4–6 seconds each) serve as **visual continuity cues** at critical narrative turning points across the 7-lesson campaign. 

> **Pedagogical Note:** These clips do **not teach** curriculum content directly. They establish dramatic atmosphere, signal major story shifts, and provide cinematic momentum between lessons. A total of **3 clips** are designated for this 7-lesson series.

---

## Clip 1 — The Storm Over Wittling Pier

**Duration Estimate:** ~5 seconds
**Scene Description:** Slow atmospheric camera pan across the sea-swept Wittling-on-Sea promenade. Dark storm clouds roll in overhead as sea spray crashes against the old wooden pier legs. A vintage paper evacuation notice flutters off a lamppost and blows past the camera into rain-slicked cobblestones.
**Tone & Atmosphere:** Atmospheric, eerie, calm before the storm.
**Audio Cue:** Howling ocean wind, distant seagulls crying, low dramatic cello drone.
**Suggested Placement:** **Lesson 1, Slide 1** (Placed immediately after the opening heading as the visual intro to the series).

### AI Video Generation Prompt
```
"Cinematic 5-second video clip. Slow panning shot of a shabby British seaside promenade during an approaching coastal storm. Dark moody storm clouds, rain-slicked cobblestones, crashing ocean waves against an old wooden pier in the background. A wet yellow paper notice flutters off a green iron lamp post and sweeps across the frame. Comic-adventure art style, saturated teal and dark amber lighting, 24fps smooth camera motion."
```

---

## Clip 2 — The Great Yeast Bubble

**Duration Estimate:** ~4 seconds
**Scene Description:** Close-up camera angle inside the town hall committee room floor. A crack between wooden floorboards opens slightly, followed by a warm golden bubble of active yeast dough oozing out, inflating, and softly popping with a small puff of steam.
**Tone & Atmosphere:** Comic mystery, intriguing, slightly absurd.
**Audio Cue:** Deep subterranean rumbling sound, squishy bubbling audio effect, high-pitched *pop*.
**Suggested Placement:** **Lesson 4, Slide 6** (Placed directly above the teaser callout box at the end of Lesson 4 to land the floor bulge teaser).

### AI Video Generation Prompt
```
"4-second macro video clip. Close-up shot of dark polished wooden floorboards in an old Victorian office room. A warm golden sourdough bubble slowly oozes up between a gap in the boards, inflates smoothly to the size of an orange, and pops gently releasing a small puff of white flour steam. High detail, warm golden lighting, funny comic-adventure aesthetic, smooth 30fps animation."
```

---

## Clip 3 — Sourdough Tsunami on High Street

**Duration Estimate:** ~6 seconds
**Scene Description:** Dynamic low-angle wide shot looking down Wittling High Street. A massive, slow-moving wall of golden sourdough dough rolls down the middle of the street between colourful storefronts, pushing a plastic deck chair gently aside. The sun breaks through rain clouds in the background.
**Tone & Atmosphere:** High-stakes comic climax, visually spectacular, non-threatening.
**Audio Cue:** Low rumbling slide sound, cheerful upbeat Brass-Band emergency fanfare.
**Suggested Placement:** **Lesson 6, Slide 1** (Placed as the opening hero clip of Lesson 6 to visually establish the sourdough explosion).

### AI Video Generation Prompt
```
"6-second wide-angle video clip. High-energy comic-adventure scene looking down a seaside town high street. A massive, smooth wave of golden bread dough slowly rolls down the center of the road between colorful shop fronts. Sunbeams slice through dramatic rain clouds above. Smooth forward tracking camera shot, vibrant saturated colors, dramatic cinematic composition, 24fps."
```

---

## Summary Matrix

| Clip # | Title | Duration | Placement | Narrative Purpose |
|---|---|---|---|---|
| **1** | The Storm Over Wittling Pier | 5s | Lesson 1, Slide 1 | Establish atmospheric seaside setting & storm threat |
| **2** | The Great Yeast Bubble | 4s | Lesson 4, Slide 6 | Provide visual payoff for the subterranean dough teaser |
| **3** | Sourdough Tsunami on High Street | 6s | Lesson 6, Slide 1 | Visual climax of the sourdough explosion |
