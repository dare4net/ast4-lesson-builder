# The Disaster Committee
### Story Bible & Premise Document
**Series:** KS3 English — Persuasive & Argumentative Writing
**Genre:** Natural Disaster Survival | **Tone:** Comic Adventure
**Year Group:** KS3 (Age 11–14)

---

## 1. World Premise

Something is very wrong in **Wittling-on-Sea**.

A Category 3 storm is sweeping in from the Atlantic. The pier is wobbling. The bunting is already gone. The mayor — the one person who should be handling all of this — is currently unreachable on a sunlounger in Tenerife.

The Emergency Disaster Committee has convened in the town hall. There are five of them. They have been arguing for three hours and have achieved exactly nothing, unless you count knocking over the biscuit display someone brought.

This is where you come in.

You are the **Junior Persuasion Officer** — a KS3 student drafted into the committee after someone noticed you'd won an argument with a vending machine last Tuesday. Your job: use the power of persuasive and argumentative writing to make this committee do something useful before the storm, the coastal flooding, and the increasingly suspicious rumblings underneath the Wittling Biscuit Factory cause the whole town to quietly fall apart.

The good news: nobody is going to get seriously hurt. This is Wittling-on-Sea. Things go wrong here all the time and somehow muddle through.
The bad news: the dough is rising.

---

## 2. Thematic Engine

> *The committee has all the authority and none of the skill. You have all the skill and none of the authority — yet. The whole series is about learning how words, when chosen well and deployed in the right form, are the most powerful disaster-response tool in the room.*

---

## 3. The Central Question

**Can the right words, in the right form, at the right moment, move people who really, really don't want to be moved?**

*(Beneath this: can you persuade someone even when they are being ridiculous?)*

---

## 4. Characters

### 🎺 Captain Mildred "Milly" Bluster
**Role:** Chairperson, Wittling-on-Sea Emergency Committee
**Public face (Lessons 1–5):** Loud, well-meaning, and completely unable to make a decision she'll stick to for more than four minutes. She changes her position based on whoever argued with her most recently. She has a clipboard, a whistle, and a very specific set of opinions about font sizes on evacuation notices.
**True arc:** By Lesson 7, it becomes clear that Milly isn't actually incompetent — she's been stalling on purpose, waiting for someone to make a genuinely convincing case, because she's terrified of making a wrong call. She's been testing the committee, including you, all along.
**Curriculum toolkit:** Milly embodies *audience* — she responds differently to pathos, logos, and ethos. What you write and how you write it determines whether she acts.
**Voice:** Overly formal phrases followed by very informal outbursts. *"I hereby move that we— oh, for pint's sake, Gerald, put that down."*

---

### 🏆 Gerald Nibbs
**Role:** Self-Appointed "Town Disaster Expert"
**Public face (Lessons 1–4):** Gerald has a diploma from an online course called *Surviving With Confidence* and treats it as equivalent to a doctorate. He announces incorrect facts with tremendous enthusiasm. He once predicted a Category 5 hurricane that turned out to be a leaf blower.
**True arc (Lesson 4 twist):** Gerald quietly passes you a note confessing he made everything up. He has no qualifications. He became the "expert" because nobody else volunteered and he thought it would look good on his CV. He is now genuinely frightened and needs someone with actual skills — you — to produce the right documents to get the committee moving.
**Curriculum toolkit:** Gerald represents *counter-argument* — you will frequently have to rebut his confident nonsense with evidence-backed reasoning.
**Voice:** Booming self-assurance that occasionally cracks. *"The storm, as I predicted — which I did — is entirely within my projected parameters."*

---

### 📚 Professor Agatha Spindle
**Role:** Town Archivist & Data Person
**Public face:** Professor Spindle has extraordinary amounts of accurate information about weather patterns, geological surveys, coastal erosion rates, and the structural integrity of Barry's biscuit factory. She cannot communicate any of it to a normal human being.
**True arc:** She realises midway through the series that she's been producing the right evidence all along — it just needed someone to translate it into persuasive human language. She becomes your quiet ally, feeding you data to deploy.
**Curriculum toolkit:** Spindle represents *logos* — data and evidence, which must be shaped with *pathos* and *ethos* to work on an audience.
**Voice:** Precise, jargon-heavy, then suddenly surprised that nobody understood her. *"The isobar pressure differential of 14.7 millibars clearly indicates— why is everyone looking at their phones?"*

---

### 🍪 Barry Potts
**Role:** Owner, Wittling Biscuit Factory
**Public face (Lessons 1–6):** Barry does not want the factory evacuated. The factory is his life, his legacy, and his main excuse for not attending any committee meeting he doesn't control. He is hilariously self-interested and produces "facts" that always somehow conclude the factory is fine and should stay open.
**True arc (Lesson 6 reversal):** The tremors under the factory are Barry's fault. Forty years of inadequately sealed biscuit dough vats have been quietly fermenting underground. The expanding dough is causing the tremors. Barry knew something was off for months but didn't want to say anything.
**Curriculum toolkit:** Barry is the opposing argument — the position you must counter, rebut, and ultimately redirect. He is never the villain; he is just very, very attached to his biscuits.
**Voice:** Aggressively cheerful deflection. *"Perfectly normal structural settling! Nothing to do with the seventeen tonnes of active dough directly below us, which doesn't exist."*

---

### 🎓 The Student (Player Character — You)
**Role:** Junior Persuasion Officer
**Arc:** Arrives thinking persuasion is just "arguing louder." Leaves the series understanding that the form, structure, tone, and technique of argument is what creates real change — and that the right words, written for the right audience, in the right format, can move even a committee full of baffled adults.

---

## 5. The World — Visual & Atmospheric Style

**Location:** Wittling-on-Sea — a pleasantly shabby British seaside town
**Art style:** Bright, bold, slightly cartoonish. Think vintage British seaside poster meets emergency warning sign. Lots of yellow and teal, striped deck chairs, seagulls with opinions, hand-painted signs.
**Recurring visual motifs:**
- Bunting that is always partially blown off
- Seagulls appearing at inconvenient moments (often stealing committee documents)
- The Wittling Pier, visibly listing, with the fortune-teller machine that only says "DOOMED"
- Evacuation notices with increasingly frantic fonts
- The biscuit factory chimney, which is gently glowing in a way it probably shouldn't be
- The town hall notice board, always covered in contradictory announcements

**Atmosphere:** Urgent but never truly frightening. The tone is that of a warm British disaster comedy — things go wrong with comedic escalation, the adults are wonderfully incompetent, and the students are the only competent force in the room.
