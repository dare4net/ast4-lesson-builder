# The Disaster Committee: Master Lesson Plan Document
### Slide-by-Slide Component Breakdowns & Cinematic Image Prompts
**Series:** KS3 English — Persuasive & Argumentative Writing
**Topic Slug:** `ks3-disaster-committee`

---

## Lesson 1 — Chapter 1: The Biscuit Tin Dilemma

**Curriculum Skills Taught:**
- Identifying and applying Aristotle's Triad of Persuasion (**Ethos, Pathos, Logos**) in written arguments.
- Distinguishing between authoritative appeal (ethos), emotional appeal (pathos), and logical evidence (logos).

**Narrative Beat:** The Emergency Committee is stuck in an endless tea break while a Category 3 storm hits. You step forward to persuade Captain Bluster to declare a Yellow Alert using persuasive triad techniques.

**Handoff Type:** Planted Suspicion
**Handoff Text:** *"As Captain Bluster agrees to put the committee on yellow alert, a sudden shudder rattles the windowpanes. But the sound didn't come from the ocean outside. It came from deep underground, right beneath the town hall... and it smelled faintly of warm yeast and butter."*

**Slide Count:** 6 Slides

---

### Slide Breakdown — Lesson 1

#### Slide 1: 🌧️ Scene 1: Emergency Committee Assembly
- **`heading`**
  - *Pedagogical purpose:* Establish lesson context.
  - *Narrative function:* Set the scene in the storm-swept Wittling Town Hall.
  - *Arrangement rationale:* Top anchor of the slide.
- **`paragraph`**
  - *Pedagogical purpose:* Introduce the narrative situation.
  - *Narrative function:* Describe Captain Bluster banging her gavel on a shortbread tin.
  - *Arrangement rationale:* Immediately follows heading for narrative setup.
- **`image`**
  - *Pedagogical purpose:* Visual anchor of the chaotic town hall meeting.
  - *Narrative function:* Establish the comedic tone and character dynamics.
  - *Arrangement rationale:* Placed centrally to give visual context before interactive elements.
- **`accordion`**
  - *Pedagogical purpose:* Explore committee members' profiles and arguments.
  - *Narrative function:* Inspect Captain Bluster, Gerald Nibbs, and Agatha Spindle's positions.
  - *Arrangement rationale:* Placed at bottom for interactive exploration after reading intro.

#### Slide 2: ⚖️ Scene 2: The Persuasive Triad (Ethos, Pathos, Logos)
- **`heading`**
  - *Pedagogical purpose:* Frame the core academic concept.
  - *Narrative function:* Introduce the "Persuasive Triad" as the junior officer's primary secret weapon.
  - *Arrangement rationale:* Header anchor.
- **`callout`** (`variant: "important"`)
  - *Pedagogical purpose:* Highlighting definition of Ethos, Pathos, and Logos.
  - *Narrative function:* Officer's Field Handbook notes.
  - *Arrangement rationale:* Placed above interactive component to ensure concept acquisition before practice.
- **`matchingPairs`**
  - *Pedagogical purpose:* Match Persuasive Pillars (Ethos/Pathos/Logos) to definitions and example quotes.
  - *Narrative function:* Decode which committee member responds to which appeal.
  - *Arrangement rationale:* Core interactive check of concept understanding.
  - *markingMode:* `auto-mark` (exact term-to-definition pairs).

#### Slide 3: 🔍 Scene 3: Analyzing Committee Arguments
- **`heading`**
  - *Pedagogical purpose:* Applied analysis of written persuasive quotes.
  - *Narrative function:* Analyze quotes from Captain Bluster, Gerald, and Agatha.
  - *Arrangement rationale:* Header anchor.
- **`categorise`**
  - *Pedagogical purpose:* Sort 6 statement cards into Ethos, Pathos, or Logos buckets.
  - *Narrative function:* Sort committee statements into the correct rhetorical category.
  - *Arrangement rationale:* Deep interactive sorting practice.
  - *markingMode:* `auto-mark` (pre-defined categories).

#### Slide 4: 🗣️ Scene 4: Crafting the Appeals
- **`heading`**
  - *Pedagogical purpose:* Sentence-level construction of persuasive appeals.
  - *Narrative function:* Help Captain Bluster draft an alert memo for the town.
  - *Arrangement rationale:* Header anchor.
- **`fillInTheBlank`**
  - *Pedagogical purpose:* Insert modal verbs, emotive words, and authoritative titles to complete persuasive sentences.
  - *Narrative function:* Drafting the yellow alert document.
  - *Arrangement rationale:* Scaffolded sentence construction.
  - *markingMode:* `self-mark` (pre-defined keyword options).

#### Slide 5: 📜 Scene 5: The Junior Officer's First Address
- **`heading`**
  - *Pedagogical purpose:* Open-ended persuasive writing synthesis.
  - *Narrative function:* Write your speech to convince Captain Bluster to officially activate Yellow Alert.
  - *Arrangement rationale:* Header anchor.
- **`shortAnswer`**
  - *Pedagogical purpose:* Write a 3-sentence persuasive paragraph combining Ethos, Pathos, and Logos.
  - *Narrative function:* Deliver your official address to the committee.
  - *Arrangement rationale:* Full open response synthesis at the end of the instructional flow.
  - *markingMode:* `tutor-mark` (requires tutor feedback on argument quality and tone).

#### Slide 6: 🚨 Scene 6: Chapter 1 Resolution & Handoff
- **`heading`**
  - *Pedagogical purpose:* Debrief and narrative handoff.
  - *Narrative function:* Captain Bluster signs the Yellow Alert order.
  - *Arrangement rationale:* Header anchor.
- **`callout`** (`variant: "warning"`)
  - *Pedagogical purpose:* Dramatic chapter ending.
  - *Narrative function:* Deliver the handoff text (ground shudder & yeast smell).
  - *Arrangement rationale:* Highlighted takeaway at bottom of slide.

---

### 🖼️ Image Generation Prompts — Lesson 1

**Slide 1 → `image`**
*Purpose:* Establish the chaotic, comic-disaster atmosphere of Wittling Town Hall.
*Prompt:*
"A vibrant, comic-adventure style illustration of a Victorian-era town hall committee room during a storm. Wind and rain rattle large arched glass windows in the background. In the foreground, a loud female committee captain in a navy coat bangs a wooden mallet onto a decorative tin of shortbread biscuits. Around a cluttered mahogany table, a puffed-up man holds up a piece of seaweed on a string, and a female professor with round spectacles unrolls an enormous complex weather graph. Bright saturated colours, teal and gold palette, lively comic aesthetic, high detail."

---

**Components used this lesson:** `heading`, `paragraph`, `image`, `accordion`, `callout`, `matchingPairs`, `categorise`, `fillInTheBlank`, `shortAnswer`.
**Variety note:** Lesson 1 uses a balanced mix of sorting (`categorise`), pairing (`matchingPairs`), and scaffolded text entry (`fillInTheBlank`). Lesson 2 will shift primary focus toward visual hotspot inspection and headline analysis to avoid duplicating the flow.

---

## Lesson 2 — Chapter 2: The Art of the Opening Hook

**Curriculum Skills Taught:**
- Writing high-impact opening hooks for persuasive speeches and articles.
- Employing rhetorical questions, emotive adjectives, and dramatic contrast.

**Narrative Beat:** Town residents ignore dull official notices. You teach the committee how to draft compelling headlines and opening statements for digital billboards.

**Handoff Type:** Discovery Object
**Handoff Text:** *"As the new digital bulletin lights up the high street, forcing walking locals to pause in their tracks, Gerald Nibbs drops his leather briefcase. Out rolls a handwritten note on official Wittling Council letterhead: 'Project Dough-Dome: DO NOT LEAK TO PUBLIC.' Gerald quickly kicks it under a radiator before you can read the rest."*

**Slide Count:** 6 Slides

---

### Slide Breakdown — Lesson 2

#### Slide 1: 📢 Scene 1: The Ignored Bulletins
- **`heading`**
  - *Pedagogical purpose:* Introduce hook concepts.
  - *Narrative function:* Townspeople throwing dull notices into recycling bins.
  - *Arrangement rationale:* Header anchor.
- **`hotspot`**
  - *Pedagogical purpose:* Inspect 4 failed notices to identify why they failed to engage readers.
  - *Narrative function:* Examine paper notices pinned around the town square.
  - *Arrangement rationale:* Interactive visual inspection as the primary opening activity.
  - *markingMode:* `self-mark` (explore mode).

#### Slide 2: ⚡ Scene 2: Hook Anatomy (The 4 Hook Engines)
- **`heading`**
  - *Pedagogical purpose:* Teach 4 hook types: Rhetorical Question, Shocking Fact, Emotive Call, Contrast.
  - *Narrative function:* Officer's Guide to Grabbing Attention.
  - *Arrangement rationale:* Header anchor.
- **`flashcards`**
  - *Pedagogical purpose:* Interactive study cards for the 4 hook types with examples.
  - *Narrative function:* Training the committee members on hook writing.
  - *Arrangement rationale:* Self-paced study before practice.

#### Slide 3: 🎯 Scene 3: Hook Transformation Workshop
- **`heading`**
  - *Pedagogical purpose:* Transforming dull sentences into powerful hooks.
  - *Narrative function:* Rewrite boring council announcements.
  - *Arrangement rationale:* Header anchor.
- **`trueFalse`**
  - *Pedagogical purpose:* Evaluate whether candidate headlines qualify as effective hooks.
  - *Narrative function:* Test Gerald's headline ideas.
  - *Arrangement rationale:* Quick binary check.
  - *markingMode:* `auto-mark`.

#### Slide 4: 🖥️ Scene 4: Digital Billboard Assembly
- **`heading`**
  - *Pedagogical purpose:* Structuring a multi-sentence persuasive opening.
  - *Narrative function:* Assemble the High Street Emergency Billboard text.
  - *Arrangement rationale:* Header anchor.
- **`dragDrop`**
  - *Pedagogical purpose:* Sequence hook components (Hook → Context → Call to Action).
  - *Narrative function:* Order the billboard messages for maximum impact.
  - *Arrangement rationale:* Order-building activity.
  - *markingMode:* `auto-mark`.

#### Slide 5: ✍️ Scene 5: Draft Your High Street Hook
- **`heading`**
  - *Pedagogical purpose:* Open-ended hook composition.
  - *Narrative function:* Write the main emergency broadcast headline.
  - *Arrangement rationale:* Header anchor.
- **`shortAnswer`**
  - *Pedagogical purpose:* Draft a 2-sentence hook combining a rhetorical question and an emotive call to action.
  - *Narrative function:* Final submission to the town digital board.
  - *Arrangement rationale:* Synthesis activity.
  - *markingMode:* `tutor-mark`.

#### Slide 6: 🤐 Scene 6: The Secret Note
- **`heading`**
  - *Pedagogical purpose:* Chapter resolution and handoff.
  - *Narrative function:* Gerald drops the secret "Project Dough-Dome" document.
  - *Arrangement rationale:* Header anchor.
- **`image`**
  - *Pedagogical purpose:* Visual anchor for the discovery handoff.
  - *Narrative function:* Show Gerald nervously kicking the document under the radiator.
  - *Arrangement rationale:* Visual conclusion.

---

### 🖼️ Image Generation Prompts — Lesson 2

**Slide 1 → `hotspot`**
*Purpose:* Interactive inspection of dull vs effective notice boards in town square.
*Prompt:*
"A broad comic-style illustration of a rain-swept town square in Wittling-on-Sea. A wooden community notice board stands in the center covered in wet, peeling paper notices reading 'NOTICE 4B: SEAWALL MAINTAINANCE'. Pedestrians with umbrellas walk past ignoring the board. Glowing neon digital sign framing the right side of the image. Saturated teal and golden lighting, detailed cartoon style."

**Slide 6 → `image`**
*Purpose:* Show the mystery document drop handoff.
*Prompt:*
"A dramatic comic-style close-up under a rusty iron radiator in a town hall hallway. A folded yellow parchment note labeled 'PROJECT DOUGH-DOME - CONFIDENTIAL' rests on dark floorboards. A man's shiny leather shoe is caught mid-kick trying to shove the paper into the dark shadow under the radiator. Warm indoor lighting contrast with dark cast shadows."

---

**Components used this lesson:** `heading`, `hotspot`, `flashcards`, `trueFalse`, `dragDrop`, `shortAnswer`, `image`.
**Variety note:** Replaced matching pairs and categorise with `hotspot` visual inspection and `dragDrop` sequencing to maintain freshness.

---

## Lesson 3 — Chapter 3: Rhetorical Artillery (AFOREST & Counter-Arguments)

**Curriculum Skills Taught:**
- Master AFOREST persuasive techniques (Alliteration, Facts, Opinions, Rhetorical questions, Emotive language, Statistics, Triples).
- Structuring counter-arguments to address and dismantle opposing viewpoints.

**Narrative Beat:** Barry Potts demands lowering the alert status to keep his biscuit shop open. You equip the committee with AFOREST techniques to counter his arguments.

**Handoff Type:** Character Twist
**Handoff Text:** *"Defeated in argument, Barry steps out into the corridor to take a private call. You overhear him whispering frantically into his mobile: 'It's expanding faster than we calculated! The yeast in Vault 4 has gone rogue—it's consumed the main support beams!'"*

**Slide Count:** 6 Slides

---

### Slide Breakdown — Lesson 3

#### Slide 1: 🥐 Scene 1: Barry Potts Demands Satisfaction
- **`heading`**
  - *Pedagogical purpose:* Frame the opposing argument conflict.
  - *Narrative function:* Barry Potts enters demanding alert reduction.
  - *Arrangement rationale:* Header anchor.
- **`paragraph`**
  - *Pedagogical purpose:* Story setup.
  - *Narrative function:* Describe Barry's argument that "dough is money, and money is safety!"
  - *Arrangement rationale:* Intro text.

#### Slide 2: 🛠️ Scene 2: The AFOREST Toolkit
- **`heading`**
  - *Pedagogical purpose:* Introduce AFOREST acronym.
  - *Narrative function:* Equipping the committee with rhetorical devices.
  - *Arrangement rationale:* Header anchor.
- **`accordion`**
  - *Pedagogical purpose:* Detailed breakdown of each letter in AFOREST with example quotes.
  - *Narrative function:* Officer's Rhetorical Toolkit.
  - *Arrangement rationale:* Interactive reference block.

#### Slide 3: 🎯 Scene 3: Identifying Rhetorical Devices
- **`heading`**
  - *Pedagogical purpose:* Practice identifying AFOREST techniques in sample sentences.
  - *Narrative function:* Analyze Barry's speeches for sneaky rhetoric.
  - *Arrangement rationale:* Header anchor.
- **`quiz`**
  - *Pedagogical purpose:* Multiple choice questions identifying Alliteration, Rule of Three, and Emotive Language.
  - *Narrative function:* Spotting the device in action.
  - *Arrangement rationale:* Core knowledge check.
  - *markingMode:* `auto-mark`.

#### Slide 4: 🛡️ Scene 4: The Counter-Argument Framework
- **`heading`**
  - *Pedagogical purpose:* Teaching the 3-step counter-argument structure (Acknowledge → Rebut → Redirect).
  - *Narrative function:* Preparing to dismantle Barry's business arguments.
  - *Arrangement rationale:* Header anchor.
- **`annotateImage`**
  - *Pedagogical purpose:* Label the 3 parts of a counter-argument paragraph on a visual speech diagram.
  - *Narrative function:* Mapping the strategy to defeat Barry's pushback.
  - *Arrangement rationale:* Visual structural breakdown.
  - *markingMode:* `auto-mark`.

#### Slide 5: ⚔️ Scene 5: Deliver the Counter-Argument
- **`heading`**
  - *Pedagogical purpose:* Open-ended counter-argument writing.
  - *Narrative function:* Write the official committee response to Barry Potts.
  - *Arrangement rationale:* Header anchor.
- **`shortAnswer`**
  - *Pedagogical purpose:* Write a paragraph acknowledging Barry's business concerns, rebutting with safety facts, and applying a Rule of Three.
  - *Narrative function:* Final speech to Barry in the committee chamber.
  - *Arrangement rationale:* Synthesis task.
  - *markingMode:* `tutor-mark`.

#### Slide 6: 📱 Scene 6: The Overheard Call
- **`heading`**
  - *Pedagogical purpose:* Chapter conclusion and handoff.
  - *Narrative function:* Overhearing Barry's secret phone call about Vault 4.
  - *Arrangement rationale:* Header anchor.
- **`callout`** (`variant: "warning"`)
  - *Pedagogical purpose:* Highlight handoff text.
  - *Narrative function:* Deliver character twist handoff.
  - *Arrangement rationale:* Bottom highlight.

---

### 🖼️ Image Generation Prompts — Lesson 3

**Slide 4 → `annotateImage`**
*Purpose:* Visual speech diagram showing 3 parts of a counter-argument paragraph.
*Prompt:*
"A clean comic-style graphic of an open parchment speech scroll pinned to a wooden easel. Three glowing highlight boxes mark different sections: Top box ('Acknowledge Opposing View'), Middle box ('Rebut with Evidence'), Bottom box ('Redirect to Action'). Saturated teal background with bright yellow text labels and arrow markers."

---

**Components used this lesson:** `heading`, `paragraph`, `accordion`, `quiz`, `annotateImage`, `shortAnswer`, `callout`.
**Variety note:** Introduced `annotateImage` for structural argument mapping and used `quiz` for quick technique identification.

---

## Lesson 4 — Chapter 4: The Fact vs. Opinion Minefield

**Curriculum Skills Taught:**
- Distinguishing verified facts from subjective opinions and biased statements.
- Identifying bias, exaggeration, and unverified claims in public statements.

**Narrative Beat:** Wild rumours spread about a 100-foot wave. Gerald Nibbs admits his qualifications are fake and begs for help writing a public retraction.

**Handoff Type:** Teaser
**Handoff Text:** *"As Gerald finishes signing the retraction statement, the floor beneath your feet bulges upwards by three inches with a loud SQUISH. A warm, golden bubble bursts through a crack in the floorboards, filling the room with the undeniable scent of vanilla and active yeast."*

**Slide Count:** 6 Slides

---

### Slide Breakdown — Lesson 4

#### Slide 1: 🌊 Scene 1: Rumour Mill Unleashed
- **`heading`**
  - *Pedagogical purpose:* Introduce concept of bias and rumour.
  - *Narrative function:* Social media and gossip causing panic in Wittling.
  - *Arrangement rationale:* Header anchor.
- **`paragraph`**
  - *Pedagogical purpose:* Story setup.
  - *Narrative function:* Gerald's blog claims a 100-foot wave is coming.
  - *Arrangement rationale:* Intro block.

#### Slide 2: ⚖️ Scene 2: Fact vs. Opinion Sorting
- **`heading`**
  - *Pedagogical purpose:* Core rule: Facts can be proven; opinions reflect feelings/beliefs.
  - *Narrative function:* Auditing town statements with Agatha Spindle.
  - *Arrangement rationale:* Header anchor.
- **`categorise`**
  - *Pedagogical purpose:* Sort 8 statements into "Verified Fact", "Unverified Opinion", or "Biased Exaggeration".
  - *Narrative function:* Filtering Gerald's blog posts.
  - *Arrangement rationale:* Core sorting exercise.
  - *markingMode:* `auto-mark`.

#### Slide 3: 🔎 Scene 3: Detecting Bias
- **`heading`**
  - *Pedagogical purpose:* Analyzing loaded words that reveal author bias.
  - *Narrative function:* Examining Gerald's articles for biased word choices.
  - *Arrangement rationale:* Header anchor.
- **`matchingPairs`**
  - *Pedagogical purpose:* Match biased loaded words (e.g. "Catastrophic") to neutral equivalents (e.g. "Elevated").
  - *Narrative function:* Neutralizing panic language.
  - *Arrangement rationale:* Vocabulary refinement task.
  - *markingMode:* `auto-mark`.

#### Slide 4: 😳 Scene 4: Gerald's Confession
- **`heading`**
  - *Pedagogical purpose:* Understand ethical responsibility in persuasive writing.
  - *Narrative function:* Gerald admits his online diploma is fake.
  - *Arrangement rationale:* Header anchor.
- **`image`**
  - *Pedagogical purpose:* Visual anchor for Gerald's emotional confession.
  - *Narrative function:* Gerald nervously holding his fake certificate.
  - *Arrangement rationale:* Visual context.

#### Slide 5: 📝 Scene 5: Draft the Retraction Statement
- **`heading`**
  - *Pedagogical purpose:* Writing objective, fact-based public retractions.
  - *Narrative function:* Help Gerald write his official retraction notice.
  - *Arrangement rationale:* Header anchor.
- **`shortAnswer`**
  - *Pedagogical purpose:* Write a 3-sentence retraction replacing Gerald's exaggerated claims with verified facts from Professor Spindle.
  - *Narrative function:* Official publication to the town board.
  - *Arrangement rationale:* Synthesis activity.
  - *markingMode:* `tutor-mark`.

#### Slide 6: 🍞 Scene 6: The Floor Bulges
- **`heading`**
  - *Pedagogical purpose:* Chapter conclusion and handoff.
  - *Narrative function:* The floor bulges with sourdough bubble.
  - *Arrangement rationale:* Header anchor.
- **`callout`** (`variant: "warning"`)
  - *Pedagogical purpose:* Highlight handoff teaser.
  - *Narrative function:* Deliver floor bulge teaser text.
  - *Arrangement rationale:* Highlight block.

---

### 🖼️ Image Generation Prompts — Lesson 4

**Slide 4 → `image`**
*Purpose:* Show Gerald's nervous confession about his fake diploma.
*Prompt:*
"A humorous comic-style illustration inside the Wittling town hall committee room. A middle-aged man in a tweed vest holds up a comical, cheap-looking certificate that reads 'DIPLOMA OF EXPERTNESS - BOUGHT ONLINE FOR £15'. He looks sweating and embarrassed, pulling at his collar. Bright indoor lighting, funny expressive character art, warm palette."

---

**Components used this lesson:** `heading`, `paragraph`, `categorise`, `matchingPairs`, `image`, `shortAnswer`, `callout`.
**Variety note:** Re-employed `categorise` and `matchingPairs` for data auditing, paired with open-ended retraction writing.

---

## Lesson 5 — Chapter 5: Crafting the Persuasive Speech (Ethos & Pacing)

**Curriculum Skills Taught:**
- Structuring a formal persuasive speech (Exordium, Narration, Argument, Refutation, Peroration).
- Using discourse markers, modal verbs of urgency (*must*, *shall*, *will*), and direct address.

**Narrative Beat:** The dough vault is about to breach. The Mayor calls in from Tenerife dismissively. You write and deliver a formal speech to convince the committee to evacuate the lower harbour immediately.

**Handoff Type:** Reversal
**Handoff Text:** *"Captain Bluster slams her fist onto the desk and authorizes the evacuation! But just as you celebrate, Agatha Spindle checks the latest seismic readings: 'Wait... it's not the sea wall breaking. The underground dough mass has reached critical pressure. It's about to blow the roof off the biscuit factory!'"*

**Slide Count:** 6 Slides

---

### Slide Breakdown — Lesson 5

#### Slide 1: 🏝️ Scene 1: Call from Tenerife
- **`heading`**
  - *Pedagogical purpose:* Establish high-stakes speech scenario.
  - *Narrative function:* The Mayor video calls from his lounge chair dismissing the crisis.
  - *Arrangement rationale:* Header anchor.
- **`paragraph`**
  - *Pedagogical purpose:* Narrative setup.
  - *Narrative function:* You need to convince Captain Bluster to override the Mayor.
  - *Arrangement rationale:* Intro block.

#### Slide 2: 🏛️ Scene 2: The 5-Part Speech Framework
- **`heading`**
  - *Pedagogical purpose:* Teach classical speech structure.
  - *Narrative function:* Officer's Blueprint for Master Speeches.
  - *Arrangement rationale:* Header anchor.
- **`timeline`**
  - *Pedagogical purpose:* Interactive ordering of speech sections (Hook → Background → Argument → Rebuttal → Call to Action).
  - *Narrative function:* Sequencing your evacuation speech.
  - *Arrangement rationale:* Chronological structure task.
  - *markingMode:* `auto-mark`.

#### Slide 3: ⚡ Scene 3: Power Verbs & Discourse Markers
- **`heading`**
  - *Pedagogical purpose:* Selecting high-urgency modal verbs and transition words.
  - *Narrative function:* Elevating the speech's authority.
  - *Arrangement rationale:* Header anchor.
- **`quiz`**
  - *Pedagogical purpose:* Choose the strongest modal verbs (*must* vs *might*, *crucial* vs *nice*) for speech impact.
  - *Narrative function:* Fine-tuning speech phrasing.
  - *Arrangement rationale:* Targeted vocabulary check.
  - *markingMode:* `auto-mark`.

#### Slide 4: 🎙️ Scene 4: Speech Rehearsal Workshop
- **`heading`**
  - *Pedagogical purpose:* Evaluating speech excerpts for rhetorical effectiveness.
  - *Narrative function:* Testing draft paragraphs on Captain Bluster.
  - *Arrangement rationale:* Header anchor.
- **`multiSelectQuiz`**
  - *Pedagogical purpose:* Identify all sentences in a draft paragraph that successfully use direct address and emotive triples.
  - *Narrative function:* Polishing the speech text.
  - *Arrangement rationale:* Multi-select evaluation task.
  - *markingMode:* `auto-mark`.

#### Slide 5: 📣 Scene 5: Deliver the Evacuation Speech
- **`heading`**
  - *Pedagogical purpose:* Full persuasive speech composition synthesis.
  - *Narrative function:* Deliver your final speech to the committee.
  - *Arrangement rationale:* Header anchor.
- **`shortAnswer`**
  - *Pedagogical purpose:* Write a 4-sentence speech paragraph using a strong opening hook, one modal verb of urgency, one discourse marker, and a direct call to action.
  - *Narrative function:* The speech that wins over Captain Bluster.
  - *Arrangement rationale:* Capstone writing synthesis for Lesson 5.
  - *markingMode:* `tutor-mark`.

#### Slide 6: 💥 Scene 6: The Roof Explodes!
- **`heading`**
  - *Pedagogical purpose:* Chapter resolution and reversal handoff.
  - *Narrative function:* The biscuit factory roof reaches critical pressure.
  - *Arrangement rationale:* Header anchor.
- **`callout`** (`variant: "important"`)
  - *Pedagogical purpose:* Highlight reversal handoff text.
  - *Narrative function:* Deliver factory explosion reversal.
  - *Arrangement rationale:* Bottom highlight.

---

### 🖼️ Image Generation Prompts — Lesson 5

**Slide 1 → `paragraph` (Visual context in header)**
*Purpose:* Show Mayor's ridiculous video call from Tenerife.
*Prompt:*
"A comic-adventure style illustration of a large monitor on a town hall wall showing a sunburned town mayor wearing sunglasses and a floral shirt on a beach, waving dismissively. Below the screen, Captain Bluster and committee members look up in frustration. Vibrant colours, funny expressions, rich detail."

---

**Components used this lesson:** `heading`, `paragraph`, `timeline`, `quiz`, `multiSelectQuiz`, `shortAnswer`, `callout`.
**Variety note:** Introduced `timeline` for speech sequencing and `multiSelectQuiz` for multi-criteria sentence evaluation.

---

## Lesson 6 — Chapter 6: The Emergency Broadcast (Adapting Tone & Medium)

**Curriculum Skills Taught:**
- Adapting persuasive and informative writing across different media formats (speech vs radio broadcast vs print notice).
- Writing concise, imperative emergency instructions under strict character/word limits.

**Narrative Beat:** Sourdough oozes down High Street. You write a live radio/loudspeaker broadcast script to direct citizens to safety without causing stampedes.

**Handoff Type:** Hard Cliffhanger
**Handoff Text:** *"The evacuation runs smoothly, but as the last resident reaches the town hill, a massive surge of dough blocks the main bridge back to safety! You, Captain Bluster, Gerald, and Barry are trapped on the pier side of the river!"*

**Slide Count:** 6 Slides

---

### Slide Breakdown — Lesson 6

#### Slide 1: 🌋 Scene 1: The Sourdough Explosion
- **`heading`**
  - *Pedagogical purpose:* Introduce media adaptation under crisis conditions.
  - *Narrative function:* Sourdough flowing down High Street.
  - *Arrangement rationale:* Header anchor.
- **`image`**
  - *Pedagogical purpose:* Visual anchor for the sourdough tsunami.
  - *Narrative function:* Show golden dough slowly overtaking the street.
  - *Arrangement rationale:* High-impact visual setup.

#### Slide 2: 📻 Scene 2: Medium & Audience Matrix
- **`heading`**
  - *Pedagogical purpose:* Compare Print, Radio, and Social Media conventions.
  - *Narrative function:* Officer's Media Adaptation Guide.
  - *Arrangement rationale:* Header anchor.
- **`matchingPairs`**
  - *Pedagogical purpose:* Match Media Type (Radio, Billboard, SMS) to key stylistic rules (e.g. Radio = clear audio cues & repetition; SMS = ultra-concise imperatives).
  - *Narrative function:* Selecting the right format for the town loudspeaker.
  - *Arrangement rationale:* Rule matching task.
  - *markingMode:* `auto-mark`.

#### Slide 3: ⏱️ Scene 3: The 30-Second Script Constraint
- **`heading`**
  - *Pedagogical purpose:* Editing text for brevity and clarity under strict word limits.
  - *Narrative function:* Trimming Agatha Spindle's 400-word broadcast draft down to 50 words.
  - *Arrangement rationale:* Header anchor.
- **`wordScramble`**
  - *Pedagogical purpose:* Unscramble key emergency imperative keywords (e.g. `EVACUATE`, `PROCEED`, `HIGHER`).
  - *Narrative function:* Unlocking emergency broadcast codes.
  - *Arrangement rationale:* Rapid keyword check.
  - *markingMode:* `auto-mark`.

#### Slide 4: 🎙️ Scene 4: Broadcast Script Editing
- **`heading`**
  - *Pedagogical purpose:* Removing filler words and jargon from broadcast scripts.
  - *Narrative function:* Polishing the radio announcement.
  - *Arrangement rationale:* Header anchor.
- **`fillInTheBlank`**
  - *Pedagogical purpose:* Fill in missing imperative verbs and direction markers in a 40-word radio script template.
  - *Narrative function:* Finalizing the loudspeaker text.
  - *Arrangement rationale:* Guided script completion.
  - *markingMode:* `self-mark`.

#### Slide 5: 🔊 Scene 5: Broadcast Live!
- **`heading`**
  - *Pedagogical purpose:* Open-ended emergency broadcast writing.
  - *Narrative function:* Write the complete 3-sentence live radio alert broadcast to the town.
  - *Arrangement rationale:* Header anchor.
- **`shortAnswer`**
  - *Pedagogical purpose:* Write a 3-sentence broadcast script containing: 1) Urgent clear hook, 2) Precise evacuation route instructions using imperatives, 3) Reassuring closing statement.
  - *Narrative function:* Broadcast your script live over the Wittling speakers.
  - *Arrangement rationale:* Synthesis activity.
  - *markingMode:* `tutor-mark`.

#### Slide 6: 🌉 Scene 6: Trapped on the Pier!
- **`heading`**
  - *Pedagogical purpose:* Chapter resolution and cliffhanger handoff.
  - *Narrative function:* The bridge is blocked by dough; committee is trapped.
  - *Arrangement rationale:* Header anchor.
- **`callout`** (`variant: "warning"`)
  - *Pedagogical purpose:* Highlight hard cliffhanger.
  - *Narrative function:* Deliver trapped on pier cliffhanger text.
  - *Arrangement rationale:* Bottom highlight.

---

### 🖼️ Image Generation Prompts — Lesson 6

**Slide 1 → `image`**
*Purpose:* Dramatic visual of sourdough tsunami flowing through Wittling High Street.
*Prompt:*
"A dramatic comic-adventure illustration of a seaside high street. A giant, slow-moving wave of golden sourdough dough is oozing down the street between quaint shops. Seagulls fly overhead in surprise. People in the background are calmly walking up a grassy hill in the distance. Saturated amber and teal lighting, cinematic perspective, rich comic detail."

---

**Components used this lesson:** `heading`, `image`, `matchingPairs`, `wordScramble`, `fillInTheBlank`, `shortAnswer`, `callout`.
**Variety note:** Used `wordScramble` for rapid keyword unlocking and focused on media adaptation mechanics.

---

## Lesson 7 — Chapter 7: The Grand Debate & Town Charter (Capstone)

**Curriculum Skills Taught:**
- Synthesizing all persuasive & argumentative techniques (Ethos/Pathos/Logos, AFOREST, Counter-arguments, Format Adaptation, Speechcraft).
- Constructing a comprehensive formal persuasive charter / closing argument.

**Narrative Beat:** Trapped in the clocktower, the committee begins infighting. You lead a formal Grand Debate and draft the Wittling Rescue Declaration to unite everyone and save the day.

**Handoff Type:** Student Challenge
**Handoff Text:** *"Safe on high ground, Captain Bluster hands you the official Wittling Silver Clipboard: 'You've mastered the art of persuasion, Officer. Now... how are you going to persuade the Mayor to pay for the cleanup?'"*

**Slide Count:** 7 Slides

---

### Slide Breakdown — Lesson 7

#### Slide 1: 🏰 Scene 1: The Clocktower Standoff
- **`heading`**
  - *Pedagogical purpose:* Set capstone challenge context.
  - *Narrative function:* Trapped in the clocktower while committee members argue over who to blame.
  - *Arrangement rationale:* Header anchor.
- **`paragraph`**
  - *Pedagogical purpose:* Narrative setup.
  - *Narrative function:* You must unite the group to build a rescue raft from pier timbers.
  - *Arrangement rationale:* Intro block.

#### Slide 2: 🧠 Scene 2: The Persuasive Master Review
- **`heading`**
  - *Pedagogical purpose:* Comprehensive review of all campaign writing concepts.
  - *Narrative function:* Unlocking the Master Persuasion Vault.
  - *Arrangement rationale:* Header anchor.
- **`spinTheWheel`**
  - *Pedagogical purpose:* Gamified review wheel testing AFOREST, Ethos/Pathos/Logos, Fact vs Opinion, and Counter-Arguments.
  - *Narrative function:* Testing the committee's knowledge before drafting the declaration.
  - *Arrangement rationale:* Gamified capstone review engine.
  - *markingMode:* `auto-mark`.

#### Slide 3: 🧩 Scene 3: Deconstruct the Master Declaration
- **`heading`**
  - *Pedagogical purpose:* Analyzing exemplary persuasive text structure.
  - *Narrative function:* Examining the Wittling Rescue Declaration outline.
  - *Arrangement rationale:* Header anchor.
- **`categorise`**
  - *Pedagogical purpose:* Categorize 6 excerpt sentences into their rhetorical function (Hook, Ethos Credibility, Pathos Appeal, Logos Evidence, Counter-Argument, Call to Action).
  - *Narrative function:* Sorting the declaration components.
  - *Arrangement rationale:* Structural categorization task.
  - *markingMode:* `auto-mark`.

#### Slide 4: 🃏 Scene 4: Memory Grid of Persuasive Devices
- **`heading`**
  - *Pedagogical purpose:* Rapid device matching review.
  - *Narrative function:* Matching persuasive devices to their dramatic impact on audiences.
  - *Arrangement rationale:* Header anchor.
- **`memoryGrid`**
  - *Pedagogical purpose:* Pair 6 persuasive technique terms with their exact definition & effect.
  - *Narrative function:* Tuning the committee's rhetorical memory.
  - *Arrangement rationale:* Memory matching review.
  - *markingMode:* `auto-mark`.

#### Slide 5: 📜 Scene 5: Write the Wittling Rescue Declaration
- **`heading`**
  - *Pedagogical purpose:* Capstone open-ended persuasive writing synthesis.
  - *Narrative function:* Draft the official Wittling Rescue Declaration to unite the committee.
  - *Arrangement rationale:* Header anchor.
- **`shortAnswer`**
  - *Pedagogical purpose:* Write a 5-sentence formal declaration containing: 1) High-impact hook, 2) Ethos/Logos evidence paragraph, 3) Counter-argument addressing fear, 4) AFOREST triple, 5) Powerful closing call to action.
  - *Narrative function:* Read your declaration to the committee to trigger raft construction.
  - *Arrangement rationale:* Master synthesis task of the entire course.
  - *markingMode:* `tutor-mark`.

#### Slide 6: ⛵ Scene 6: The Great Escape
- **`heading`**
  - *Pedagogical purpose:* Narrative climax & achievement recognition.
  - *Narrative function:* The raft is built; the committee sails safely to the town hill.
  - *Arrangement rationale:* Header anchor.
- **`image`**
  - *Pedagogical purpose:* Visual climax showing the heroic escape.
  - *Narrative function:* Show the committee sailing on a wooden pier-plank raft atop golden sourdough toward the sunset hill.
  - *Arrangement rationale:* Hero visual anchor.

#### Slide 7: 🏆 Scene 7: Graduation & Silver Clipboard Award
- **`heading`**
  - *Pedagogical purpose:* Course completion debrief & student challenge.
  - *Narrative function:* Captain Bluster awards you the Silver Clipboard.
  - *Arrangement rationale:* Header anchor.
- **`lessonComplete`**
  - *Pedagogical purpose:* Final celebratory screen with badge.
  - *Narrative function:* Deliver final student challenge handoff text.
  - *Arrangement rationale:* Final completion node.

---

### 🖼️ Image Generation Prompts — Lesson 7

**Slide 6 → `image`**
*Purpose:* Heroic comic visual of committee escaping on a pier-timber raft.
*Prompt:*
"A triumphant, comic-adventure illustration of a wooden raft built from pier planks and life preservers sailing smoothly across a sea of golden dough. On the raft, Captain Bluster holds up a silver clipboard heroically, GeraldNibbs steers with an oar, Professor Spindle checks a map, and a young student stands at the bow smiling. The sun sets in warm gold and purple behind the grassy town hill in the background. Rich detail, cinematic lighting, epic comic style."

---

**Components used this lesson:** `heading`, `paragraph`, `spinTheWheel`, `categorise`, `memoryGrid`, `shortAnswer`, `image`, `lessonComplete`.
**Variety note:** Deployed `spinTheWheel` and `memoryGrid` for capstone review, ending with a comprehensive synthesis writing task and celebratory completion block.
