# The Disaster Committee: Full Story Document
### Chapter-by-Chapter Narrative & Handoff Arc
**Series:** KS3 English — Persuasive & Argumentative Writing
**Topic Slug:** `ks3-disaster-committee`

---

## 📖 ACT I: THE GATHERING STORM (Lessons 1–3)

### Lesson 1 — Chapter 1: The Biscuit Tin Dilemma
**Narrative:**
It is 08:30 AM at the Wittling-on-Sea Town Hall. Outside, the wind is howling across the promenade, knocking over plastic garden chairs. Inside, the Emergency Disaster Committee is locked in a heated debate over whether to issue an evacuation warning for the low-lying east pier or order a tea break first. 

Captain Milly Bluster opens the meeting by banging a wooden gavel against a tin of shortbread. Gerald Nibbs insists that his "proprietary weather barometer"—a piece of seaweed tied to a string—indicates "fine weather with a chance of drizzle." Meanwhile, Professor Agatha Spindle tries to present a 40-page technical report on rising tide levels, but nobody can understand her graphs.

As the Junior Persuasion Officer, you step up to deliver your first argument. You must persuade Captain Bluster that an emergency protocol is urgently required, using **Aristotle's Triad of Persuasion (Ethos, Pathos, and Logos)** to balance credibility, emotional urgency, and facts.

**Handoff Type:** *Planted Suspicion*
**Handoff Text:**
> As Captain Bluster agrees to put the committee on yellow alert, a sudden shudder rattles the windowpanes. But the sound didn't come from the ocean outside. It came from deep underground, right beneath the town hall... and it smelled faintly of warm yeast and butter.

---

### Lesson 2 — Chapter 2: The Art of the Opening Hook
**Narrative:**
The storm warning has been raised to Amber, but the town residents are ignoring the council's dull, bullet-pointed paper notices. "PEOPLE OF WITTLING: PLEASE OBSERVE SAFETY GUIDELINES" gets tossed straight into recycling bins.

Captain Bluster admits that nobody is reading the official warnings. You explain that persuasion starts before the reader even finishes the first sentence: you need a powerful **Opening Hook**. You teach the committee how to draft compelling headlines and opening statements using rhetorical questions, shocking statistics, emotive language, and dramatic contrast. 

Together with Agatha Spindle, you write a series of high-impact emergency bulletins for the town square digital billboard.

**Handoff Type:** *Discovery Object*
**Handoff Text:**
> As the new digital bulletin lights up the high street, forcing walking locals to pause in their tracks, Gerald Nibbs drops his leather briefcase. Out rolls a handwritten note on official Wittling Council letterhead: *"Project Dough-Dome: DO NOT LEAK TO PUBLIC."* Gerald quickly kicks it under a radiator before you can read the rest.

---

### Lesson 3 — Chapter 3: Rhetorical Artillery (AFOREST & Counter-Arguments)
**Narrative:**
With the storm escalating, local business owner Barry Potts marches into the town hall demanding the committee lower the alert status. Barry claims the warnings are scaring away his morning pastry customers and hurting local trade.

To stand up to Barry's loud rhetoric, you equip the committee with **AFOREST techniques** (Alliteration, Facts, Opinions, Rhetorical questions, Emotive language, Statistics, Triples/Rule of Three). You construct a counter-argument showing that protecting human life and property ultimately safeguards local business.

Faced with your structured rebuttal, Barry backs down, but his nervous glances toward the industrial district suggest he is hiding something bigger than a dip in scone sales.

**Handoff Type:** *Character Twist*
**Handoff Text:**
> Defeated in argument, Barry steps out into the corridor to take a private call. You overhear him whispering frantically into his mobile: *"It's expanding faster than we calculated! The yeast in Vault 4 has gone rogue—it's consumed the main support beams!"*

---

## 📖 ACT II: CRACKS IN THE FOUNDATION (Lessons 4–5)

### Lesson 4 — Chapter 4: The Fact vs. Opinion Minefield
**Narrative:**
Rumours are flying across Wittling-on-Sea. Panic spreads on social media, with exaggerated claims that a 100-foot tidal wave is about to swallow the pier. Gerald Nibbs is fueling the hysteria by publishing unverified claims on his personal blog.

You must step in to separate **Fact from Opinion and Bias**. You guide the committee in auditing public statements, identifying bias, and verifying statistical evidence from Professor Spindle's data.

During the audit, Gerald breaks down. He admits his "Surviving With Confidence" diploma was bought online for £15 and he has no idea how to interpret sea-level data. He begs you to help him write a formal retraction that maintains public calm without causing total panic.

**Handoff Type:** *Teaser*
**Handoff Text:**
> As Gerald finishes signing the retraction statement, the floor beneath your feet bulges upwards by three inches with a loud *SQUISH*. A warm, golden bubble bursts through a crack in the floorboards, filling the room with the undeniable scent of vanilla and active yeast.

---

### Lesson 5 — Chapter 5: Crafting the Persuasive Speech (Ethos & Pacing)
**Narrative:**
The situation is critical. The expanding dough vault underneath Barry's factory has combined with rising storm waters, threatening to breach the sea wall. The Town Mayor (calling in via video call from Tenerife) wants to dismiss the danger and resume his vacation.

You are tasked with writing and delivering a **Persuasive Speech to the Council Board**. You structure the speech using clear paragraphing, discourse markers, modal verbs of urgency (*must*, *should*, *will*), and direct audience address.

Your speech convinces Captain Bluster to take full charge and order an immediate evacuation of the lower harbour.

**Handoff Type:** *Reversal*
**Handoff Text:**
> Captain Bluster slams her fist onto the desk and authorizes the evacuation! But just as you celebrate, Agatha Spindle checks the latest seismic readings: *"Wait... it's not the sea wall breaking. The underground dough mass has reached critical pressure. It's about to blow the roof off the biscuit factory!"*

---

## 📖 ACT III: THE CRISIS & RESOLUTION (Lessons 6–7)

### Lesson 6 — Chapter 6: The Emergency Broadcast (Adapting Tone & Medium)
**Narrative:**
The biscuit factory's roof has exploded in a spectacular cascade of dough and sprinkles! High-pressure sourdough is oozing down High Street toward the harbour. The town needs immediate, clear instructions on how to reach higher ground safely.

You must adapt your persuasive writing for a **Live Emergency Broadcast Script**. You learn how language changes across different formats and media: short sentences for clarity, imperatives for action, and empathetic tone to prevent stampedes.

You broadcast the announcement over the town loudspeaker network, directing citizens to safety cleanly and efficiently.

**Handoff Type:** *Hard Cliffhanger*
**Handoff Text:**
> The evacuation runs smoothly, but as the last resident reaches the town hill, a massive surge of dough blocks the main bridge back to safety! You, Captain Bluster, Gerald, and Barry are trapped on the pier side of the river!

---

### Lesson 7 — Chapter 7: The Grand Debate & Town Charter (Capstone)
**Narrative:**
Trapped in the clocktower above the rising dough line, Barry Potts, Captain Bluster, and Gerald Nibbs begin blaming each other for the disaster. 

To resolve the standoff and unite everyone to build a rescue raft from pier timbers, you lead a formal **Grand Debate & Declaration**. You synthesize every technique learned across the campaign: ethos/pathos/logos, AFOREST, counter-argument, audience adaptation, and formal speechcraft.

With your masterpiece declaration read aloud, the committee works together, builds the escape vessel, and sails safely to the town hill to a hero's welcome.

**Handoff Type:** *Student Challenge*
**Handoff Text:**
> Safe on high ground, Captain Bluster hands you the official Wittling Silver Clipboard: *"You've mastered the art of persuasion, Officer. Now... how are you going to persuade the Mayor to pay for the cleanup?"*

---

## 🎭 Emotional Arc Summary
- **Opening (Lessons 1–2):** Amused confusion & curiosity. The student feels like the only sensible person in a room full of chaotic adults.
- **Midpoint (Lessons 3–5):** Growing confidence & investigative focus. The student realizes their words have real power to control outcomes and unearth secrets.
- **Climax (Lessons 6–7):** High-stakes leadership & empowerment. The student takes full command of the room, using persuasive eloquence to rescue the town.
